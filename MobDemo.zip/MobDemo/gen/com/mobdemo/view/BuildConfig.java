/** Automatically generated file. DO NOT MODIFY */
package com.mobdemo.view;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}